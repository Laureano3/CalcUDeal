"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Search, Plus, Edit } from "lucide-react"
import Image from "next/image"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { useToast } from "@/hooks/use-toast"
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog"
import CalculatorForm from "@/components/calculator-form"
import UserMenu from "@/components/user-menu"
import { useAuth } from "@/components/auth-context"
import { useAdmin } from "@/components/admin-context"

export default function Home() {
  const [searchTerm, setSearchTerm] = useState("")
  const [showForm, setShowForm] = useState(false)
  const [editingCalculator, setEditingCalculator] = useState<any>(null)
  const { toast } = useToast()
  const { user } = useAuth()
  const { approvedCalculators, addCalculator, isAdmin } = useAdmin()
  const router = useRouter()

  const userIsAdmin = isAdmin(user?.email)

  // Filter calculators based on search term
  const filteredCalculators = approvedCalculators.filter(
    (calculator) =>
      calculator.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      calculator.model.toLowerCase().includes(searchTerm.toLowerCase()) ||
      calculator.seller.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  // Handle contact request
  const handleContactRequest = (calculator: any) => {
    if (!user) {
      toast({
        title: "Acceso denegado",
        description: "Debes iniciar sesión para solicitar contactos de vendedores",
        variant: "destructive",
      })
      router.push("/login")
      return
    }

    toast({
      title: "Solicitud enviada",
      description: `Te contactaremos pronto con los datos de ${calculator.seller} para la calculadora ${calculator.name}.`,
      duration: 5000,
    })
  }

  // Add new calculator
  const handleAddCalculator = (newCalculator: any) => {
    // Enviar para aprobación
    addCalculator(newCalculator, user?.id)
    setShowForm(false)
    setEditingCalculator(null)
  }

  // Start editing a calculator
  const handleEditCalculator = (calculator: any) => {
    setEditingCalculator(calculator)
    setShowForm(true)
  }

  // Close form and reset editing state
  const handleCloseForm = () => {
    setShowForm(false)
    setEditingCalculator(null)
  }

  return (
    <main className="container mx-auto py-8 px-4">
      <header className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">CalcUDeal</h1>
        <div className="flex items-center gap-4">
          {userIsAdmin && (
            <Button variant="outline" onClick={() => router.push("/admin")}>
              Panel de Administración
            </Button>
          )}
          <UserMenu />
        </div>
      </header>

      {/* Search and Add button */}
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between max-w-4xl mx-auto mb-12">
        <div className="relative w-full md:max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Buscar calculadora por nombre, modelo o vendedor..."
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <Dialog open={showForm} onOpenChange={handleCloseForm}>
          <DialogTrigger asChild>
            <Button className="whitespace-nowrap">
              <Plus className="mr-2 h-4 w-4" /> Añadir Calculadora
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <CalculatorForm
              onAddCalculator={handleAddCalculator}
              initialData={editingCalculator || undefined}
              isEditing={!!editingCalculator}
            />
          </DialogContent>
        </Dialog>
      </div>

      {/* Calculator catalog */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCalculators.map((calculator) => (
          <Card key={calculator.id} className="overflow-hidden">
            <CardHeader className="p-0">
              <div className="relative h-48 w-full bg-muted">
                <Image
                  src={calculator.image || "/placeholder.svg?height=200&width=200"}
                  alt={calculator.name}
                  fill
                  className="object-contain p-4"
                  unoptimized={calculator.image?.startsWith("http")}
                />
                {userIsAdmin && (
                  <Button
                    size="icon"
                    variant="ghost"
                    className="absolute top-2 right-2 bg-background/80 hover:bg-background/90"
                    onClick={() => handleEditCalculator(calculator)}
                  >
                    <Edit className="h-4 w-4" />
                    <span className="sr-only">Editar</span>
                  </Button>
                )}
              </div>
            </CardHeader>
            <CardContent className="p-6">
              <CardTitle className="mb-2">{calculator.name}</CardTitle>
              <div className="space-y-2 text-sm">
                <p>
                  <span className="font-medium">Modelo:</span> {calculator.model}
                </p>
                <p>
                  <span className="font-medium">Precio:</span> €{calculator.price.toFixed(2)}
                </p>
                <p>
                  <span className="font-medium">Vendedor:</span> {calculator.seller}
                </p>
                <p>
                  <span className="font-medium">Programable:</span> {calculator.programmable ? "Sí" : "No"}
                </p>
              </div>
            </CardContent>
            <CardFooter>
              <Button
                className="w-full"
                onClick={() => handleContactRequest(calculator)}
                variant={user ? "default" : "outline"}
              >
                {user ? "Solicitar contacto del vendedor" : "Inicia sesión para solicitar contacto"}
              </Button>
            </CardFooter>
          </Card>
        ))}

        {filteredCalculators.length === 0 && (
          <div className="col-span-full text-center py-12">
            <p className="text-muted-foreground">No se encontraron calculadoras que coincidan con tu búsqueda.</p>
          </div>
        )}
      </div>
    </main>
  )
}

