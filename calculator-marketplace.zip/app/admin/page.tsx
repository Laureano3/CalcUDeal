"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { Check, X, ArrowLeft } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"
import { useAuth } from "@/components/auth-context"
import { useAdmin } from "@/components/admin-context"
import { Badge } from "@/components/ui/badge"

export default function AdminPage() {
  const router = useRouter()
  const { toast } = useToast()
  const { user } = useAuth()
  const { pendingCalculators, approveCalculator, rejectCalculator, isAdmin } = useAdmin()

  // Verificar si el usuario es administrador
  useEffect(() => {
    if (!user || !isAdmin(user.email)) {
      toast({
        title: "Acceso denegado",
        description: "No tienes permisos para acceder al panel de administración",
        variant: "destructive",
      })
      router.push("/")
    }
  }, [user, isAdmin, router, toast])

  // Si no hay usuario o no es admin, no mostrar nada
  if (!user || !isAdmin(user.email)) {
    return null
  }

  return (
    <main className="container mx-auto py-8 px-4">
      <div className="flex items-center gap-4 mb-8">
        <Button variant="ghost" size="icon" onClick={() => router.push("/")}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-3xl font-bold">Panel de Administración</h1>
      </div>

      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Calculadoras pendientes de aprobación</h2>

        {pendingCalculators.length === 0 ? (
          <div className="text-center py-12 bg-muted rounded-lg">
            <p className="text-muted-foreground">No hay calculadoras pendientes de aprobación</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {pendingCalculators.map((calculator) => (
              <Card key={calculator.id} className="overflow-hidden">
                <CardHeader className="p-0">
                  <div className="relative h-48 w-full bg-muted">
                    <Image
                      src={calculator.image || "/placeholder.svg?height=200&width=200"}
                      alt={calculator.name}
                      fill
                      className="object-contain p-4"
                      unoptimized={calculator.image?.startsWith("http")}
                    />
                    <Badge className="absolute top-2 left-2 bg-yellow-500">Pendiente</Badge>
                  </div>
                </CardHeader>
                <CardContent className="p-6">
                  <CardTitle className="mb-2">{calculator.name}</CardTitle>
                  <div className="space-y-2 text-sm">
                    <p>
                      <span className="font-medium">Modelo:</span> {calculator.model}
                    </p>
                    <p>
                      <span className="font-medium">Precio:</span> €{calculator.price.toFixed(2)}
                    </p>
                    <p>
                      <span className="font-medium">Vendedor:</span> {calculator.seller}
                    </p>
                    <p>
                      <span className="font-medium">Programable:</span> {calculator.programmable ? "Sí" : "No"}
                    </p>
                    <p>
                      <span className="font-medium">Enviado por:</span> {calculator.submittedBy}
                    </p>
                    <p>
                      <span className="font-medium">Fecha:</span>{" "}
                      {calculator.submittedAt ? new Date(calculator.submittedAt).toLocaleString() : "Desconocida"}
                    </p>
                  </div>
                </CardContent>
                <CardFooter className="flex gap-2">
                  <Button className="flex-1" variant="outline" onClick={() => rejectCalculator(calculator.id)}>
                    <X className="mr-2 h-4 w-4" /> Rechazar
                  </Button>
                  <Button className="flex-1" onClick={() => approveCalculator(calculator.id)}>
                    <Check className="mr-2 h-4 w-4" /> Aprobar
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
      </div>
    </main>
  )
}

