import type React from "react"
import { Toaster } from "@/components/ui/toaster"
import { ThemeProvider } from "@/components/theme-provider"
import { AuthProvider } from "@/components/auth-context"
import { AdminProvider } from "@/components/admin-context"
import "./globals.css"

export const metadata = {
  title: "CalcUDeal",
  description: "Encuentra las mejores calculadoras para tus necesidades",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="es">
      <body>
        <ThemeProvider attribute="class" defaultTheme="light">
          <AuthProvider>
            <AdminProvider>
              {children}
              <Toaster />
            </AdminProvider>
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}



import './globals.css'