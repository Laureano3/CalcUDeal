"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

type User = {
  id: string
  name: string
  email: string
  avatar?: string
}

interface AuthContextType {
  user: User | null
  isLoading: boolean
  login: (email: string, password: string) => Promise<boolean>
  register: (name: string, email: string, password: string) => Promise<boolean>
  logout: () => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

// Simulated user database
const USERS_STORAGE_KEY = "calcudeal-users"
const SESSION_STORAGE_KEY = "calcudeal-session"

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  // Load user session on mount
  useEffect(() => {
    const loadSession = () => {
      const sessionData = localStorage.getItem(SESSION_STORAGE_KEY)
      if (sessionData) {
        try {
          const userData = JSON.parse(sessionData)
          setUser(userData)
        } catch (error) {
          console.error("Failed to parse session data:", error)
        }
      }
      setIsLoading(false)
    }

    loadSession()
  }, [])

  // Get users from local storage
  const getUsers = (): Record<string, User & { password: string }> => {
    const usersData = localStorage.getItem(USERS_STORAGE_KEY)
    if (usersData) {
      try {
        return JSON.parse(usersData)
      } catch (error) {
        console.error("Failed to parse users data:", error)
      }
    }
    return {}
  }

  // Save users to local storage
  const saveUsers = (users: Record<string, User & { password: string }>) => {
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users))
  }

  // Login function
  const login = async (email: string, password: string): Promise<boolean> => {
    setIsLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 500))

    const users = getUsers()
    const userRecord = Object.values(users).find((u) => u.email === email)

    if (userRecord && userRecord.password === password) {
      const { password: _, ...userWithoutPassword } = userRecord
      setUser(userWithoutPassword)
      localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(userWithoutPassword))
      setIsLoading(false)
      return true
    }

    setIsLoading(false)
    return false
  }

  // Register function
  const register = async (name: string, email: string, password: string): Promise<boolean> => {
    setIsLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 500))

    const users = getUsers()

    // Check if email already exists
    if (Object.values(users).some((u) => u.email === email)) {
      setIsLoading(false)
      return false
    }

    // Create new user
    const newUser = {
      id: Date.now().toString(),
      name,
      email,
      password,
      avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=random`,
    }

    // Save user
    users[newUser.id] = newUser
    saveUsers(users)

    // Log in the new user
    const { password: _, ...userWithoutPassword } = newUser
    setUser(userWithoutPassword)
    localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(userWithoutPassword))

    setIsLoading(false)
    return true
  }

  // Logout function
  const logout = () => {
    setUser(null)
    localStorage.removeItem(SESSION_STORAGE_KEY)
  }

  return <AuthContext.Provider value={{ user, isLoading, login, register, logout }}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

