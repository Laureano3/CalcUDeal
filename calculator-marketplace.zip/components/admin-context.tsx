"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useToast } from "@/hooks/use-toast"

// Tipos de datos
type Calculator = {
  id: number
  name: string
  model: string
  price: number
  seller: string
  image: string
  programmable: boolean
  status?: "pending" | "approved" | "rejected"
  submittedBy?: string
  submittedAt?: string
}

interface AdminContextType {
  pendingCalculators: Calculator[]
  approvedCalculators: Calculator[]
  addCalculator: (calculator: Omit<Calculator, "id" | "status" | "submittedAt">, userId?: string) => void
  approveCalculator: (id: number) => void
  rejectCalculator: (id: number) => void
  isAdmin: (email?: string | null) => boolean
}

const ADMIN_EMAIL = "calcudealicai@gmail.com"
const CALCULATORS_STORAGE_KEY = "calcudeal-calculators"
const PENDING_CALCULATORS_STORAGE_KEY = "calcudeal-pending-calculators"

const AdminContext = createContext<AdminContextType | undefined>(undefined)

// Datos iniciales de calculadoras
const initialCalculators = [
  {
    id: 1,
    name: "Hp Prime",
    model: "Calculadora Gráfica táctil",
    price: 80,
    seller: "Laureano Salcines Cubría",
    image: "https://m.media-amazon.com/images/I/71XJvzSCe1L._AC_SY879_.jpg",
    programmable: true,
    status: "approved" as const,
  },
  {
    id: 2,
    name: "Básica Estudiantil",
    model: "Calculadora técnica ClassWiz FX-991",
    price: 19.99,
    seller: "Lucía Garbayo Bugeda",
    image: "/placeholder.svg?height=200&width=200",
    programmable: false,
    status: "approved" as const,
  },
  {
    id: 3,
    name: "Hp Prime",
    model: "Calculadora Gráfica táctil",
    price: 90,
    seller: "Pablo Lomba Martinez",
    image: "/placeholder.svg?height=200&width=200",
    programmable: true,
    status: "approved" as const,
  },
]

export function AdminProvider({ children }: { children: ReactNode }) {
  const [pendingCalculators, setPendingCalculators] = useState<Calculator[]>([])
  const [approvedCalculators, setApprovedCalculators] = useState<Calculator[]>(initialCalculators)
  const { toast } = useToast()

  // Cargar calculadoras al iniciar
  useEffect(() => {
    const loadCalculators = () => {
      // Cargar calculadoras aprobadas
      const storedCalculators = localStorage.getItem(CALCULATORS_STORAGE_KEY)
      if (storedCalculators) {
        try {
          setApprovedCalculators(JSON.parse(storedCalculators))
        } catch (error) {
          console.error("Error al cargar calculadoras aprobadas:", error)
        }
      } else {
        // Si no hay calculadoras guardadas, guardar las iniciales
        localStorage.setItem(CALCULATORS_STORAGE_KEY, JSON.stringify(initialCalculators))
      }

      // Cargar calculadoras pendientes
      const storedPendingCalculators = localStorage.getItem(PENDING_CALCULATORS_STORAGE_KEY)
      if (storedPendingCalculators) {
        try {
          setPendingCalculators(JSON.parse(storedPendingCalculators))
        } catch (error) {
          console.error("Error al cargar calculadoras pendientes:", error)
        }
      }
    }

    loadCalculators()
  }, [])

  // Guardar calculadoras cuando cambien
  useEffect(() => {
    localStorage.setItem(CALCULATORS_STORAGE_KEY, JSON.stringify(approvedCalculators))
  }, [approvedCalculators])

  useEffect(() => {
    localStorage.setItem(PENDING_CALCULATORS_STORAGE_KEY, JSON.stringify(pendingCalculators))
  }, [pendingCalculators])

  // Verificar si un usuario es administrador
  const isAdmin = (email?: string | null) => {
    return email === ADMIN_EMAIL
  }

  // Añadir una nueva calculadora (pendiente de aprobación)
  const addCalculator = (calculatorData: Omit<Calculator, "id" | "status" | "submittedAt">, userId?: string) => {
    const newCalculator: Calculator = {
      ...calculatorData,
      id: Date.now(),
      status: "pending",
      submittedBy: userId || "anonymous",
      submittedAt: new Date().toISOString(),
    }

    setPendingCalculators((prev) => [...prev, newCalculator])

    // Simular envío de notificación por email
    simulateSendEmail(newCalculator)

    toast({
      title: "Calculadora enviada para revisión",
      description: "Un administrador revisará tu calculadora antes de publicarla.",
    })
  }

  // Aprobar una calculadora
  const approveCalculator = (id: number) => {
    const calculator = pendingCalculators.find((calc) => calc.id === id)
    if (!calculator) return

    // Mover de pendiente a aprobada
    const updatedCalculator = { ...calculator, status: "approved" as const }
    setApprovedCalculators((prev) => [...prev, updatedCalculator])
    setPendingCalculators((prev) => prev.filter((calc) => calc.id !== id))

    toast({
      title: "Calculadora aprobada",
      description: `La calculadora ${calculator.name} ha sido aprobada y publicada.`,
    })
  }

  // Rechazar una calculadora
  const rejectCalculator = (id: number) => {
    const calculator = pendingCalculators.find((calc) => calc.id === id)
    if (!calculator) return

    // Eliminar de pendientes
    setPendingCalculators((prev) => prev.filter((calc) => calc.id !== id))

    toast({
      title: "Calculadora rechazada",
      description: `La calculadora ${calculator.name} ha sido rechazada.`,
    })
  }

  // Simular envío de email (en una aplicación real, esto se haría en el servidor)
  const simulateSendEmail = (calculator: Calculator) => {
    console.log(`
      [SIMULACIÓN DE EMAIL]
      Para: ${ADMIN_EMAIL}
      Asunto: Nueva calculadora pendiente de aprobación
      
      Una nueva calculadora ha sido enviada para su aprobación:
      
      Nombre: ${calculator.name}
      Modelo: ${calculator.model}
      Precio: €${calculator.price}
      Vendedor: ${calculator.seller}
      Enviado por: ${calculator.submittedBy}
      Fecha: ${new Date(calculator.submittedAt || "").toLocaleString()}
      
      Por favor, revisa esta calculadora en el panel de administración.
    `)
  }

  return (
    <AdminContext.Provider
      value={{
        pendingCalculators,
        approvedCalculators,
        addCalculator,
        approveCalculator,
        rejectCalculator,
        isAdmin,
      }}
    >
      {children}
    </AdminContext.Provider>
  )
}

export function useAdmin() {
  const context = useContext(AdminContext)
  if (context === undefined) {
    throw new Error("useAdmin debe usarse dentro de un AdminProvider")
  }
  return context
}

