"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

type Calculator = {
  id?: number
  name: string
  model: string
  price: number | string
  seller: string
  image: string
  programmable: boolean
}

interface CalculatorFormProps {
  onAddCalculator: (calculator: any) => void
  initialData?: Calculator
  isEditing?: boolean
}

export default function CalculatorForm({ onAddCalculator, initialData, isEditing = false }: CalculatorFormProps) {
  const [calculator, setCalculator] = useState<Calculator>({
    name: "",
    model: "",
    price: "",
    seller: "",
    image: "",
    programmable: false,
  })

  // Initialize form with data if editing
  useEffect(() => {
    if (initialData) {
      setCalculator(initialData)
    }
  }, [initialData])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onAddCalculator({
      ...calculator,
      id: calculator.id || Date.now(),
      price: Number.parseFloat(calculator.price as string) || 0,
    })

    // Only reset form if not editing
    if (!isEditing) {
      setCalculator({
        name: "",
        model: "",
        price: "",
        seller: "",
        image: "",
        programmable: false,
      })
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target
    setCalculator({
      ...calculator,
      [name]: type === "checkbox" ? checked : value,
    })
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>{isEditing ? "Editar Calculadora" : "Añadir Nueva Calculadora"}</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Nombre</Label>
            <Input id="name" name="name" value={calculator.name} onChange={handleChange} required />
          </div>

          <div className="space-y-2">
            <Label htmlFor="model">Modelo</Label>
            <Input id="model" name="model" value={calculator.model} onChange={handleChange} required />
          </div>

          <div className="space-y-2">
            <Label htmlFor="price">Precio (€)</Label>
            <Input
              id="price"
              name="price"
              type="number"
              step="0.01"
              min="0"
              value={calculator.price}
              onChange={handleChange}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="seller">Vendedor</Label>
            <Input id="seller" name="seller" value={calculator.seller} onChange={handleChange} required />
          </div>

          <div className="space-y-2">
            <Label htmlFor="image">URL de la Imagen</Label>
            <Input
              id="image"
              name="image"
              type="url"
              placeholder="https://ejemplo.com/imagen.jpg"
              value={calculator.image}
              onChange={handleChange}
            />
            <p className="text-xs text-muted-foreground">Pega la URL de una imagen de Google u otra fuente</p>
          </div>

          <div className="space-y-2">
            <Label>Programable</Label>
            <RadioGroup
              value={calculator.programmable ? "yes" : "no"}
              onValueChange={(value) => setCalculator({ ...calculator, programmable: value === "yes" })}
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="yes" id="programmable-yes" />
                <Label htmlFor="programmable-yes">Sí</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="no" id="programmable-no" />
                <Label htmlFor="programmable-no">No</Label>
              </div>
            </RadioGroup>
          </div>

          <Button type="submit" className="w-full">
            {isEditing ? "Guardar Cambios" : "Añadir Calculadora"}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}

